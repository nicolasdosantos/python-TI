base = int(input("Qual a base do seu triangulo"))
altura = int(input("Qual a altura do seu triangulo"))
perimetro = altura*2 + base
area= (base*altura)/2
print(f"Seu perimetro é de {perimetro}, e sua area é de {area}")
num=int(input("Digite um numero"))
antes = num-1
depois = num+1
print(f"Seu numero é {num}, seu antecessor é {antes} e seu sucessor é {depois}")
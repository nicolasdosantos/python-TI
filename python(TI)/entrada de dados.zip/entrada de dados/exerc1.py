num = int(input("Digite seu numero"))
quadrado = num**2
print(f"O valor ao quadrado é:{quadrado}")
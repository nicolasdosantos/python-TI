num1=int(input("Digite o primeiro numero"))
num2=int(input("Digete o segundo numero"))
print(f"Seu primeiro numero foi {num1} e seu segundo foi{nu2}")
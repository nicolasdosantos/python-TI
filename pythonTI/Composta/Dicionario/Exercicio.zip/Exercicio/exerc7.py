from random import randint

jogadores = {'Basinga': randint(1,6), 'Lara': randint(1,6), 'Nicolas': randint(1,6), 'Miguel': randint(1,6)}

print(jogadores)
while True:
    g = input("Qual seu genero?\nMasculino(M)\nFeminino(F)\nR:")
    if g != "M" and g != "F":
        print("\n**Voce digitou errado tente novamente**\n")
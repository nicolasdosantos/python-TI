#while 30 < 20:
#    print("Ola mundo")

#while 10 < 20:
#    print("Ola mundo")

#num = 0
#while num < 20:
#    print(num)
#    num += 1

#Res = 'S'
#while Res == "S":
#    num = int(input("Digite um numero\nR:"))
#    if num > 999:
#        print("Seu numero é muito grande")
#       break
#    Res = str(input('Deseja continuar?S/N\nR:'))

#|while True:
#    ini = str(input('Digite comecar'))
#    if ini != "comecar":
#        print("Não digitou certo reveja")
#    else:
#        break

nota = 0
media = 0
while True:
    notas = int(input('Digite sua nota '))
    nota += notas
    media += 1
    if media >=5:
        cal= nota/media
        print(f"Sua media é de {cal}")
        break

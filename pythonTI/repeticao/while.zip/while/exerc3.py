Res = 'S'
while Res == "S":
    num = int(input("Digite um numero\nR:"))
    if num >= 999 or num <= 0:
        print("Seu numero é invalido!")
        break
